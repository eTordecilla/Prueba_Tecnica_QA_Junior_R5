import unittest
import HtmlTestRunner
from selenium import webdriver
from pages.Page_Complete_Form import *
from pages.Page_Navigator import *

class TestLoginForm(unittest.TestCase):

    def setUp(self):
        self.driver = webdriver.Chrome(executable_path="./resources/webDriver/chromedriver.exe")
        print("INCICIANDO...")
        self.driver.get("https://www.saucedemo.com/")
        self.driver.implicitly_wait(10)
        print("MAXIMIZAR VENTANA")
        self.driver.maximize_window()
        
    def test_email_validation(self):

        # Se completa el Login
        autocomplete_form = Page_Complete_Form(self.driver)
        autocomplete_form.complete_form("standard_user", "secret_sauce")
        autocomplete_form.submit_form()
        
    def tearDown(self):
        self.driver.close()

if __name__ == "__main__":
        unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output="reports"))