from selenium.webdriver.common.by import By

class Page_Complete_Form():
    def __init__(self, driver):
        self.driver = driver

    def complete_form(self, username, password):
        # Se seleccionan los campos del formulario
        username_input = self.driver.find_element(by=By.ID, value="user-name")
        password_input = self.driver.find_element(by=By.ID, value="password")

        # Se completan los campos del formulario
        print("SE INGRESAN DATOS EN EL INPUT 'USUARIO'")
        username_input.send_keys(username)
        
        print("SE INGRESAN DATOS EN EL INPUT 'CONTRASEÑA'")
        password_input.send_keys(password)

        self.driver.implicitly_wait(10)

    def submit_form(self):
        # Se hace click en el boton para enviar el formulario
        submit_button = self.driver.find_element(by=By.ID, value="login-button")
        print("SE HACE CLICK EN 'ENVIAR'")
        submit_button.click()
        self.driver.implicitly_wait(10)
        